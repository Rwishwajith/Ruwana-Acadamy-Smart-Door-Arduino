
#ifndef FAKE_ESP8266_PERI_H
#define FAKE_ESP8266_PERI_H

const int GPI = 0;
const int GPO = 0;
const int GP16I = 0;

#endif